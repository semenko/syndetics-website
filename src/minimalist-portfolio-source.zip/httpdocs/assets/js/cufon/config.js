/*
 * 	Cufon Configurations
 */

Cufon.replace('h1, h2', { fontFamily: 'Aller', hover: 'true' });
Cufon.replace('.header a', { fontFamily: 'Aller', hover: 'false' });
Cufon.replace('.welcome p', { fontFamily: 'Aller', hover: 'false' });
Cufon.replace('a.btn', { fontFamily: 'Aller', hover: 'True' });

